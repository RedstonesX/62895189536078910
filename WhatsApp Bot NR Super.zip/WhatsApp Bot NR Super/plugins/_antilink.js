let linkRegex = /https:\/\/chat.whatsapp.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i
module.exports = {
  before(m, { isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe) return true
    let chat = global.db.data.chats[m.chat]
    let isGroupLink = linkRegex.exec(m.text)

    if (chat.antiLink && isGroupLink) {
      m.reply(`*[!]* Anti Link WhatsApp Group

Link Group WhatsApp terdeteksi. Selamat Tinggal kawan!

Jika menurut anda ini adalah kesalahan, silahkan hubungi *Atmint* untuk meminta invite anda kembali.

Note: Owner group tidak akan di kick. Jika admin group terkick silahkan minta *Atmint* lain untuk menginvite
`)
      this.groupRemove(m.chat, [m.sender])
    }
    return true
  }
}
