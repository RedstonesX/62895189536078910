const roles = {
  /*
  'Role Name': <Minimal Level To Obtain this Role>
  */
  'Iron 1': 0,
  'Iron 2': 10,
  'Iron 3': 20,
  'Bronze 1': 40,
  'Bronze 2': 50,
  'Bronze 3': 60,
  'Silver 1': 80,
  'Silver 2': 90,
  'Silver 3': 100,
  'Gold 1': 120,
  'Gold 2': 130,
  'Gold 3': 140,
  'Platinum 1': 160,
  'Platinum 2': 170,
  'Platinum 3': 180,
  'Platinum 3': 200,
  'Diamond 1': 220,
  'Diamond 2': 230,
  'Diamond 3': 240,
  'Immortal 1': 300,
  'Immortal 2': 400,
  'Immortal 3': 500,
  'Radiant': 1000,
  'RX': 160000
}

module.exports = {
  before(m) {
    let user = global.db.data.users[m.sender]
    let level = user.level
    let role = (Object.entries(roles).sort((a, b) => b[1] - a[1]).find(([,minLevel]) => level >= minLevel) || Object.entries(roles)[0])[0]
    user.role = role
    return true
  }
}
