let handler = async (m, { conn, text }) => {
    let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text
    else who = m.chat
    if (!who) throw `tag please`
    if (global.prems.includes(who.split`@`[0])) throw 'Dia sudah S-User!'
    global.prems.push(`${who.split`@`[0]}`)
    conn.reply(m.chat, `*[!]* Super User\n\n*@${who.split`@`[0]}* Sekarang anda S-User!`, m, {
        contextInfo: {
            mentionedJid: [who]
        }
    })

}
handler.help = ['addprem [@user]']
handler.tags = ['owner']
handler.command = /^(add|tambah|\+)prem$/i

handler.rowner = true

module.exports = handler
