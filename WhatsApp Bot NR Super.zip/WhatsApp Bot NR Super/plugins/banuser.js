let handler = async (m, { conn, text }) => {
    if (!text) throw 'siapa WOY yang bener ae'
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw 'Tag woy yang bener ae'
    let users = global.db.data.users
    users[who].banned = true
    conn.reply(m.chat, `*[!]* BOT Information

User telah terblokir dan tidak akan bisa menggunakan bot lagi`, m)
}
handler.help = ['ban']
handler.tags = ['owner']
handler.command = /^ban$/i
handler.rowner = true

module.exports = handler
