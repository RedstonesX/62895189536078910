let handler = async (m, { command, usedPrefix, text }) => {
    let which = command.replace(/get/i, '')
    if (!text) throw `Ketik *${usedPrefix}list${which}* untuk melihat pesan yang disimpan di Cloud`
    let msgs = global.db.data.msgs
    if (!text in msgs) throw `'${text}' tidak disimpan di Cloud`
    delete msgs[text]
    m.reply(`*[!]* Cloud

Nama: *${text}*
Status: *Terhapus*
File anda terhapus selamanya`)
}
handler.help = ['vn', 'msg', 'video', 'gif', 'audio', 'img', 'sticker'].map(v => 'del' + v + ' <teks>')
handler.tags = ['database']
handler.command = /^(-|del)(vn|msg|video|audio|img|stic?ker|gif)$/

module.exports = handler
