module.exports = Object.assign(async function handler(m, { conn, text }) {
    let hash = text
    if (m.quoted && m.quoted.fileSha256) hash = m.quoted.fileSha256.toString('hex')
    if (!hash) throw 'Hash not found'
    let sticker = global.db.data.sticker[hash]
    if (sticker) return m.reply(` *[!]* Informasi

fileSha256: *${hash}*
Teks: *${sticker.text}*
Waktu Dibuat: *${sticker.at}*
Terkunci: *${sticker.locked ? 'Terkunci' : 'Tidak Terkunci'}*
Nama Pembuat: *${conn.getName(sticker.creator)}*
Nomor Pembuat: *${splitM(sticker.creator)}*
Pembuat: *${sticker.creator}*


${sticker.mentionedJid.length > 0 ? `*Cmd Mention:*

${sticker.mentionedJid.map((v, i) => `No. *${i + 1}*:\n*Nama:* ${conn.getName(v)}\n*Nomor:* ${splitM(v)}\n*Jid:* ${v}`).join('\n\n')}` : ''} 
`.trim())
    else m.reply('Sticker Not in the database')
}, {
    help: ['cmd'].map(v => 'info' + v + ' <text>'),
    tags: ['database'],
    command: ['infocmd']
})

/**
 * split Jid
 * @param {String} jid 
 * @returns String
 */
function splitM(jid) {
    return jid.split('@')[0]
}