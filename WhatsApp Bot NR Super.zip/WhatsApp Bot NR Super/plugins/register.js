const { createHash } = require('crypto')
let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i
let handler = async function (m, { text, usedPrefix }) {
  let user = global.db.data.users[m.sender]
  if (user.registered === true) throw `Jika anda ingin mendaftar ulang silahkan ketik ${usedPrefix}unreg SERIAL NUMBER / KODE UNIK`
  if (!Reg.test(text)) throw `Format salah\nKetik *${usedPrefix}daftar nama.umur*`
  let [_, name, splitter, age] = text.match(Reg)
  if (!name) throw 'Nama jangan kosong atau tidak valid'
  if (!age) throw 'Umur jangan kosong atau tidak valid'
  age = parseInt(age)
  if (age > 80) throw 'Umur terlalu tua. Maksimal *80* Tahun'
  if (age < 13) throw 'Umur terlalu muda. Minimal *13* Tahun'
  user.name = name.trim()
  user.age = age
  user.regTime = + new Date
  user.registered = true
  let sn = createHash('md5').update(m.sender).digest('hex')
  m.reply(` *[!]* Registrasi

Nama: *${name}*
Umur: *${age} tahun*
Serial Number / Kode Unik: *${sn}*
Silahkan simpan *KODE UNIK* anda untuk keperluan penting seperti mendaftar ulang
`.trim())
}
handler.help = ['daftar', 'reg', 'register'].map(v => v + ' <nama>.<umur>')
handler.tags = ['exp']

handler.command = /^(daftar|reg(ister)?)$/i

module.exports = handler

