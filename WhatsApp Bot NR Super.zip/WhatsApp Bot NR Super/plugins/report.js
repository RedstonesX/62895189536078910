// By RC047 :V

let handler = async(m, { conn, text }) => {
    if (!text) throw 'Masukan Laporan!'
    const laporan = `*[!]* Laporan\n\nNomor : wa.me/${m.sender.split`@`[0]}\nPesan : ${text}`
    for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid && v != '6285755423987@s.whatsapp.net'))
    m.reply(laporan, jid)
    m.reply(laporan, m.sender) // Mwehehehehe
    m.reply('Laporan telah diterima. Silahkan tunggu Owner Bot menanggapi. Jika laporan tersebut main main akan di blokir oleh bot')
}
handler.help = ['bug', 'report'].map(v => v + ' <laporan>')
handler.tags = ['info']
handler.command = /^(bug|report)$/i

module.exports = handler
